# Roadmap

- [x] CLI skeleton
- [ ] Trace normalization
- [ ] Replay
- [ ] HTML reports
- [ ] Visual timeline
