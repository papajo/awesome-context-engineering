# Agent MRI

MRI for AI agents — inspect, trace, replay, and diagnose why an agent succeeded or failed.

## Install

```bash
pnpm install
pnpm dev
```

## Example

```bash
agent-mri analyze examples/simple-agent/trace.json
```

Outputs:

- report.md
- report.json

## Architecture

Trace → Parser → Event Store → Analyzer → Reporter
