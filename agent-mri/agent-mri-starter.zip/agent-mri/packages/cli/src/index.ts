#!/usr/bin/env node
import fs from "fs";
import { parseTrace } from "../../parser/src/parser";
import { detectContextLoss } from "../../analyzers/src/contextLoss";
import { render } from "../../reporter/src/report";

const file = process.argv[3];
if(!file){
 console.log("usage: agent-mri analyze trace.json");
 process.exit(1);
}

const events=parseTrace(fs.readFileSync(file,"utf8"));
const result=detectContextLoss(events);
console.log(render(result));
