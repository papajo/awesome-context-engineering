import { AgentEvent } from "../../core/src/types";

export function parseTrace(input:string): AgentEvent[] {
  return JSON.parse(input);
}
