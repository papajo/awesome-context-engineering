export function render(result:any){
return `# Agent MRI Report

Root Cause: ${result?.issue ?? "None detected"}
Confidence: ${Math.round((result?.confidence ?? 0)*100)}%
`;
}
