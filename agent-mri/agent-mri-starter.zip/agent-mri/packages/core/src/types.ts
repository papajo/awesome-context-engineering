export type EventType =
 | "input"
 | "memory"
 | "retrieve"
 | "tool"
 | "reason"
 | "output";

export interface AgentEvent {
  id: string;
  timestamp: number;
  type: EventType;
  tokens: number;
  payload: Record<string, unknown>;
}
