import { AgentEvent } from "../../core/src/types";

export function detectContextLoss(events:AgentEvent[]){
 const retrieval = events.filter(e=>e.type==="retrieve");
 if(retrieval.length===0){
   return {issue:"Context starvation", confidence:0.9};
 }
 return null;
}
